# Interactive UX/UI Portfolio with Data Insights

This project integrates Google Cloud APIs for real-time user tracking. It includes a user analytics component to display real-time data from users interacting with the portfolio. The project aims to enhance the user experience through dynamic feedback and analytics.
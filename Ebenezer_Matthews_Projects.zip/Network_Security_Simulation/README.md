# Network Security Simulation Project

This project simulates a network environment to assess vulnerabilities and security risks. It includes a vulnerability scanner using `nmap` to detect open ports and a basic network monitoring tool using `psutil` to log ongoing network connections.